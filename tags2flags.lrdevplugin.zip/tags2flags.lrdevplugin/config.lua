--Look in <user_home>\My Documents\AgSdkDeprecation.log
sdkDeprecation.action=throw|log
loggers.AgSdkDeprecation = {
logLevel = "info",
action = "logfile",
}