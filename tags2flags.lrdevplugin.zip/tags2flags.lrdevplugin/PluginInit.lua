
_G.pluginID = "com.ableblue.lightroom.tags2flags"
_G.URL = "http://www.github.com/MatthewMcD"



  