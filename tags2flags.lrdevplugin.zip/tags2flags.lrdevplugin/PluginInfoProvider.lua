require 'PluginManager'
return {
    sectionsForTopOfDialog = PluginManager.sectionsForTopOfDialog,
    endDialog = PluginManager.endDialog,
}
